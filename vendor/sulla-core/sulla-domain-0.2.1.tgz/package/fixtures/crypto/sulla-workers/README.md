# Cryptographic known-answer vectors

- `account-auth-v1.json` — proves account-auth v1 KDF and authentication-hash derivation from a synthetic password and parameters; old path: `tests/fixtures/account-auth-v1.json`.
- `files-sync-v1-kat.json` — proves Sulla Files sync v1 subkeys, chunk wire encoding, manifest envelope, state hash, head, and escrow derivations; old path: `tests/fixtures/files-sync-v1-kat.json`.
- `files-sync-namespace-v2-kat.json` — proves Files sync namespace v2 manifest/chunk contract, valid values, and invalid-value rejection cases; old path: `tests/fixtures/files-sync-namespace-v2-kat.json`.
- `tools-invoke-v1.json` — proves the sulla-tools-invoke-v1 device-signature message and signature against a deterministic synthetic key/input vector; old path: `tests/vectors/tools-invoke-v1.json`.
