# Cryptographic known-answer fixtures

- `account-auth-v1.json` — proves account-auth v1 derivation and vault-sync bundle v2 values; old path: `tests/fixtures/account-auth-v1.json`.
- `files-sync-v1-kat.json` — proves Sulla Files sync v1 key derivation, chunk encoding, and manifest envelope values; old path: `tests/fixtures/files-sync-v1-kat.json`.
- `files-sync-namespace-v2-kat.json` — proves Files sync namespace v2 manifest validation for valid and invalid folder/file/restore cases; old path: `tests/fixtures/files-sync-namespace-v2-kat.json`.
- `vault-sync-v3-kat.json` — proves Passwords sync v3 desktop bundle and record known-answer values; old path: `tests/fixtures/vault-sync-v3-kat.json`.
