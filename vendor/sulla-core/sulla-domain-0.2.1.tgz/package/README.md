# @sulla/domain

One implementation of the domain logic Sulla Desktop, Cloud (web + Workers) and Mobile used to copy.
Plan: `Projects/sulla-desktop/oop-review/ARCHITECTURE-PLAN.md` §9. Apps switch over in their own rebuild stages.

## Layout

```
src/support/      Bytes, RandomSource, DomainException (shared by every area)
src/crypto/       key derivation, key wrapping, Files sync v1 + namespace v2 codecs, vault sync v3, tools-invoke v1
src/vault/        item types, TOTP, password generator, Bitwarden import, autofill URL matching
src/files/        File/Folder/Version models, tombstone + conflict rules, editor registry, .sulla format
src/validation/   email, names, paths, limits
tests/<area>/     one test file per class
fixtures/crypto/<repo>/, fixtures/parity/<repo>/   verbatim copies of each app's fixtures (see MANIFEST.json)
DIFFERENCES.md    every place the old copies disagreed and which behaviour this package keeps
```

## Rules

- Classes only, constructor injection, no module-level mutable state. Runtime facilities (randomness, clock,
  crypto primitives) are injected; never read `globalThis.crypto` inside business logic (BL-015).
- No Node-only APIs in `src/` (no `Buffer`, `node:*`). Tests may use Node.
- Wire formats are frozen: every known-answer vector in `fixtures/` must pass unchanged. When old copies
  disagree, keep the behaviour production depends on and record it in DIFFERENCES.md.
- Tests fail only when real behaviour breaks: known-answer, property (fast-check) and one regression test per
  BUG-LEDGER item, named `BL-0xx: …`. No copy, markup or snapshot tests.
- Errors are `DomainException` subclasses with the stable `code` the apps already use on the wire.
